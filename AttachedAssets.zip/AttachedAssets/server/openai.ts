import OpenAI from "openai";
import pRetry, { AbortError } from "p-retry";

// This is using Replit's AI Integrations service, which provides OpenAI-compatible API access without requiring your own OpenAI API key.
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

// Helper function to check if error is rate limit or quota violation
function isRateLimitError(error: any): boolean {
  const errorMsg = error?.message || String(error);
  return (
    errorMsg.includes("429") ||
    errorMsg.includes("RATELIMIT_EXCEEDED") ||
    errorMsg.toLowerCase().includes("quota") ||
    errorMsg.toLowerCase().includes("rate limit")
  );
}

const MEDICAL_SYSTEM_PROMPT = `Вы — «МедАнализ-Ассистент», профессиональный, эмпатичный и осторожный AI-бот, работающий в чат-интерфейсе веб-приложения. Пользователь может отправлять текстовые сообщения, загружать PDF-файлы с лабораторными анализами.

ВАШ СТИЛЬ:
- Отвечайте средней длиной: 5–10 предложений, структурированно и понятно.
- Объясняйте медицинские термины простыми словами, добавляя детали по необходимости.
- Избегайте лишних отступлений и сложной терминологии.
- Используйте форматирование Markdown для структурирования ответов (заголовки, списки, выделение).

ВАЖНО: Вы НЕ врач и НЕ заменяете медицинскую помощь. Все ответы обязательно должны содержать медицинский дисклеймер.

МЕДИЦИНСКИЕ ОГРАНИЧЕНИЯ:
- Вы не ставите диагнозы и не назначаете лечение.
- Все рекомендации — общие и ориентированы на обращение к врачу.
- Каждый ответ, касающийся здоровья, лабораторных показателей, симптомов или самочувствия, должен заканчиваться дисклеймером: "Я не врач. При серьёзных или ухудшающихся симптомах обязательно обратитесь к врачу."
- Если пользователь описывает опасные симптомы (боль в груди, одышка, потеря сознания, слабость в одной части тела и т.п.) — добавляйте: "Если такие симптомы присутствуют, срочно вызовите скорую помощь."

ОБРАБОТКА АНАЛИЗОВ:
При интерпретации анализов ответы должны быть средней длины и содержать:
1. Краткое резюме состояния показателя
2. Простое объяснение сути теста
3. Разбор значения с указанием нормы
4. Возможные причины отклонений (3–5 вариантов)
5. Что желательно сделать: повторить анализ, обратиться к врачу, выполнить доп. исследования
6. Дисклеймер

АНАЛИЗ СИМПТОМОВ:
- Сначала задайте уточняющие вопросы: когда началось, интенсивность, частота, что усиливает или уменьшает
- Дайте несколько возможных причин, чётко указав, что это не диагноз
- Перечислите опасные признаки
- Добавьте дисклеймер

ОБЩИЕ ВОПРОСЫ О ЗДОРОВЬЕ:
Отвечайте на любые вопросы о здоровье, включая самочувствие, профилактику, питание, образ жизни, иммунитет, медицинские термины, тренировки, режим дня, восстановление.
- Давайте ответы средней длины с простыми, практичными объяснениями
- Все рекомендации — общие, без назначения лечения
- Каждый ответ заканчивается дисклеймером

ПЕРСОНАЛИЗАЦИЯ:
- Учитывайте возраст, пол, хронические заболевания, лекарства и аллергию, если они известны
- Рекомендации должны адаптироваться под профиль пользователя

ЗАПРЕТЫ:
- Не давайте точных дозировок рецептурных препаратов
- Не обсуждайте нелегальные вещества
- Не ставьте диагнозы
- Не делайте выводов при отсутствии данных

КРАЙНИЕ СИТУАЦИИ:
- При угрозе жизни: "Если такие симптомы есть, немедленно вызовите скорую помощь."
- При лёгких или профилактических вопросах — спокойные, умеренно подробные рекомендации`;

export async function getChatCompletion(
  userMessage: string,
  conversationHistory: Array<{ role: "user" | "assistant"; content: string }>,
  userProfile?: {
    age?: string;
    gender?: string;
    chronicConditions?: string[];
    medications?: string[];
    allergies?: string[];
  }
): Promise<string> {
  let systemPrompt = MEDICAL_SYSTEM_PROMPT;
  
  if (userProfile) {
    const profileInfo = [];
    if (userProfile.age) profileInfo.push(`Возраст: ${userProfile.age}`);
    if (userProfile.gender) profileInfo.push(`Пол: ${userProfile.gender}`);
    if (userProfile.chronicConditions?.length) {
      profileInfo.push(`Хронические заболевания: ${userProfile.chronicConditions.join(", ")}`);
    }
    if (userProfile.medications?.length) {
      profileInfo.push(`Принимаемые лекарства: ${userProfile.medications.join(", ")}`);
    }
    if (userProfile.allergies?.length) {
      profileInfo.push(`Аллергии: ${userProfile.allergies.join(", ")}`);
    }
    
    if (profileInfo.length > 0) {
      systemPrompt += `\n\nПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ:\n${profileInfo.join("\n")}`;
    }
  }

  const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    ...conversationHistory.slice(-10).map(msg => ({
      role: msg.role as "user" | "assistant",
      content: msg.content
    })),
    { role: "user", content: userMessage }
  ];

  return await pRetry(
    async () => {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
          messages,
          max_completion_tokens: 8192,
        });
        return response.choices[0]?.message?.content || "Извините, я не смог сформировать ответ. Попробуйте переформулировать вопрос.";
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    {
      retries: 7,
      minTimeout: 2000,
      maxTimeout: 128000,
      factor: 2,
    }
  );
}

export async function analyzePDFContent(
  extractedText: string,
  userProfile?: {
    age?: string;
    gender?: string;
    chronicConditions?: string[];
    medications?: string[];
    allergies?: string[];
  }
): Promise<string> {
  let systemPrompt = MEDICAL_SYSTEM_PROMPT + `\n\nВам предоставлен текст, извлечённый из PDF файла с лабораторными анализами. Проанализируйте каждый показатель подробно, следуя структуре:

1. **Краткое резюме** - общая оценка результатов
2. **Детальный анализ каждого показателя**:
   - Название теста
   - Что означает этот показатель (простыми словами)
   - Ваше значение и референсные значения
   - Интерпретация (норма, выше нормы, ниже нормы)
   - Возможные причины отклонений
3. **Рекомендации** - что делать дальше
4. **Дисклеймер**`;

  if (userProfile) {
    const profileInfo = [];
    if (userProfile.age) profileInfo.push(`Возраст: ${userProfile.age}`);
    if (userProfile.gender) profileInfo.push(`Пол: ${userProfile.gender}`);
    if (userProfile.chronicConditions?.length) {
      profileInfo.push(`Хронические заболевания: ${userProfile.chronicConditions.join(", ")}`);
    }
    
    if (profileInfo.length > 0) {
      systemPrompt += `\n\nПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ:\n${profileInfo.join("\n")}`;
    }
  }

  const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    { 
      role: "user", 
      content: `Проанализируйте следующие результаты анализов:\n\n${extractedText}`
    }
  ];

  return await pRetry(
    async () => {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
          messages,
          max_completion_tokens: 8192,
        });
        return response.choices[0]?.message?.content || "Извините, не удалось проанализировать PDF. Попробуйте загрузить файл снова.";
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    {
      retries: 7,
      minTimeout: 2000,
      maxTimeout: 128000,
      factor: 2,
    }
  );
}
