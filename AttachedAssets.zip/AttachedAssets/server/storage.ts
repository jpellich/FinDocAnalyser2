import { 
  type User, 
  type InsertUser,
  type UserProfile,
  type InsertUserProfile,
  type ChatMessage,
  type InsertChatMessage,
  type MedicationReminder,
  type InsertMedicationReminder,
  type LabResult,
  type InsertLabResult
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createOrUpdateUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  
  getChatMessages(userId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  getMedicationReminders(userId: string): Promise<MedicationReminder[]>;
  createMedicationReminder(reminder: InsertMedicationReminder): Promise<MedicationReminder>;
  deleteMedicationReminder(id: string, userId: string): Promise<boolean>;
  
  getLabResults(userId: string): Promise<LabResult[]>;
  createLabResult(result: InsertLabResult): Promise<LabResult>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private userProfiles: Map<string, UserProfile>;
  private chatMessages: Map<string, ChatMessage[]>;
  private medicationReminders: Map<string, MedicationReminder[]>;
  private labResults: Map<string, LabResult[]>;

  constructor() {
    this.users = new Map();
    this.userProfiles = new Map();
    this.chatMessages = new Map();
    this.medicationReminders = new Map();
    this.labResults = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    return this.userProfiles.get(userId);
  }

  async createOrUpdateUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const existing = this.userProfiles.get(profile.userId);
    const userProfile: UserProfile = {
      id: existing?.id || randomUUID(),
      userId: profile.userId,
      age: profile.age ?? null,
      gender: profile.gender ?? null,
      chronicConditions: profile.chronicConditions ?? null,
      medications: profile.medications ?? null,
      allergies: profile.allergies ?? null,
    };
    this.userProfiles.set(profile.userId, userProfile);
    return userProfile;
  }

  async getChatMessages(userId: string): Promise<ChatMessage[]> {
    return this.chatMessages.get(userId) || [];
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const chatMessage: ChatMessage = {
      id: randomUUID(),
      userId: message.userId,
      role: message.role,
      content: message.content,
      timestamp: new Date(),
      metadata: message.metadata ?? null,
    };
    
    const userMessages = this.chatMessages.get(message.userId) || [];
    userMessages.push(chatMessage);
    this.chatMessages.set(message.userId, userMessages);
    
    return chatMessage;
  }

  async getMedicationReminders(userId: string): Promise<MedicationReminder[]> {
    return this.medicationReminders.get(userId) || [];
  }

  async createMedicationReminder(reminder: InsertMedicationReminder): Promise<MedicationReminder> {
    const medicationReminder: MedicationReminder = {
      id: randomUUID(),
      userId: reminder.userId,
      medication: reminder.medication,
      dose: reminder.dose,
      times: reminder.times,
      frequency: reminder.frequency,
      startDate: reminder.startDate,
      endDate: reminder.endDate ?? null,
      notes: reminder.notes ?? null,
    };
    
    const userReminders = this.medicationReminders.get(reminder.userId) || [];
    userReminders.push(medicationReminder);
    this.medicationReminders.set(reminder.userId, userReminders);
    
    return medicationReminder;
  }

  async deleteMedicationReminder(id: string, userId: string): Promise<boolean> {
    const userReminders = this.medicationReminders.get(userId) || [];
    const filtered = userReminders.filter(r => r.id !== id);
    
    if (filtered.length === userReminders.length) {
      return false;
    }
    
    this.medicationReminders.set(userId, filtered);
    return true;
  }

  async getLabResults(userId: string): Promise<LabResult[]> {
    return this.labResults.get(userId) || [];
  }

  async createLabResult(result: InsertLabResult): Promise<LabResult> {
    const labResult: LabResult = {
      id: randomUUID(),
      userId: result.userId,
      fileName: result.fileName,
      extractedText: result.extractedText,
      analysis: result.analysis ?? null,
      uploadDate: new Date(),
    };
    
    const userResults = this.labResults.get(result.userId) || [];
    userResults.push(labResult);
    this.labResults.set(result.userId, userResults);
    
    return labResult;
  }
}

export const storage = new MemStorage();
