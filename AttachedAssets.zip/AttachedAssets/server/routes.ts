import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getChatCompletion, analyzePDFContent } from "./openai";
import multer from "multer";
import { PDFParse } from "pdf-parse";
import { z } from "zod";
import { insertUserProfileSchema, insertMedicationReminderSchema } from "@shared/schema";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

const DEFAULT_USER_ID = "default-user";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message || typeof message !== "string") {
        return res.status(400).json({ error: "Message is required" });
      }

      const userProfile = await storage.getUserProfile(DEFAULT_USER_ID);
      const existingMessages = await storage.getChatMessages(DEFAULT_USER_ID);
      
      await storage.createChatMessage({
        userId: DEFAULT_USER_ID,
        role: "user",
        content: message,
        metadata: null,
      });

      const conversationHistory = existingMessages.map(msg => ({
        role: msg.role as "user" | "assistant",
        content: msg.content
      }));

      const aiResponse = await getChatCompletion(
        message,
        conversationHistory,
        userProfile ? {
          age: userProfile.age || undefined,
          gender: userProfile.gender || undefined,
          chronicConditions: userProfile.chronicConditions || undefined,
          medications: userProfile.medications || undefined,
          allergies: userProfile.allergies || undefined,
        } : undefined
      );

      await storage.createChatMessage({
        userId: DEFAULT_USER_ID,
        role: "assistant",
        content: aiResponse,
        metadata: null,
      });

      res.json({ success: true });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ error: error.message || "Failed to process chat message" });
    }
  });

  app.get("/api/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages(DEFAULT_USER_ID);
      res.json(messages);
    } catch (error: any) {
      console.error("Get messages error:", error);
      res.status(500).json({ error: error.message || "Failed to get messages" });
    }
  });

  app.post("/api/upload-pdf", upload.single("pdf"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "PDF file is required" });
      }

      const parser = new PDFParse({ data: req.file.buffer });
      const result = await parser.getText();
      const extractedText = result.text;
      await parser.destroy();

      if (!extractedText || extractedText.trim().length === 0) {
        return res.status(400).json({ error: "Could not extract text from PDF" });
      }

      await storage.createLabResult({
        userId: DEFAULT_USER_ID,
        fileName: req.file.originalname,
        extractedText,
        analysis: null,
      });

      await storage.createChatMessage({
        userId: DEFAULT_USER_ID,
        role: "user",
        content: `[Загружен PDF файл: ${req.file.originalname}]`,
        metadata: { type: "pdf_upload", fileName: req.file.originalname },
      });

      const userProfile = await storage.getUserProfile(DEFAULT_USER_ID);
      
      const analysis = await analyzePDFContent(
        extractedText,
        userProfile ? {
          age: userProfile.age || undefined,
          gender: userProfile.gender || undefined,
          chronicConditions: userProfile.chronicConditions || undefined,
          medications: userProfile.medications || undefined,
          allergies: userProfile.allergies || undefined,
        } : undefined
      );

      await storage.createChatMessage({
        userId: DEFAULT_USER_ID,
        role: "assistant",
        content: analysis,
        metadata: { type: "pdf_analysis", fileName: req.file.originalname },
      });

      res.json({ success: true, analysis });
    } catch (error: any) {
      console.error("PDF upload error:", error);
      res.status(500).json({ error: error.message || "Failed to process PDF" });
    }
  });

  app.get("/api/profile", async (req, res) => {
    try {
      const profile = await storage.getUserProfile(DEFAULT_USER_ID);
      res.json(profile || null);
    } catch (error: any) {
      console.error("Get profile error:", error);
      res.status(500).json({ error: error.message || "Failed to get profile" });
    }
  });

  app.post("/api/profile", async (req, res) => {
    try {
      const validatedData = insertUserProfileSchema.parse({
        ...req.body,
        userId: DEFAULT_USER_ID,
      });

      const profile = await storage.createOrUpdateUserProfile(validatedData);
      res.json(profile);
    } catch (error: any) {
      console.error("Save profile error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid profile data", details: error.errors });
      }
      res.status(500).json({ error: error.message || "Failed to save profile" });
    }
  });

  app.get("/api/reminders", async (req, res) => {
    try {
      const reminders = await storage.getMedicationReminders(DEFAULT_USER_ID);
      res.json(reminders);
    } catch (error: any) {
      console.error("Get reminders error:", error);
      res.status(500).json({ error: error.message || "Failed to get reminders" });
    }
  });

  app.post("/api/reminders", async (req, res) => {
    try {
      const validatedData = insertMedicationReminderSchema.parse({
        ...req.body,
        userId: DEFAULT_USER_ID,
      });

      const reminder = await storage.createMedicationReminder(validatedData);
      res.json(reminder);
    } catch (error: any) {
      console.error("Create reminder error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid reminder data", details: error.errors });
      }
      res.status(500).json({ error: error.message || "Failed to create reminder" });
    }
  });

  app.delete("/api/reminders/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteMedicationReminder(id, DEFAULT_USER_ID);
      
      if (!deleted) {
        return res.status(404).json({ error: "Reminder not found" });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error("Delete reminder error:", error);
      res.status(500).json({ error: error.message || "Failed to delete reminder" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
