import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Send, 
  Upload, 
  FileText, 
  AlertTriangle, 
  Loader2, 
  Bell,
  User,
  Command,
  X
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { ChatMessage, MedicationReminder, UserProfile } from "@shared/schema";

import { PDFUpload } from "@/components/pdf-upload";
import { ReminderList } from "@/components/reminder-list";
import { ProfileForm } from "@/components/profile-form";
import { CommandPalette } from "@/components/command-palette";
import { MedicalDisclaimer } from "@/components/medical-disclaimer";

export default function Home() {
  const [message, setMessage] = useState("");
  const [showPdfUpload, setShowPdfUpload] = useState(false);
  const [showReminders, setShowReminders] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showCommands, setShowCommands] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: messages = [], isLoading: messagesLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/messages"],
  });

  const { data: profile } = useQuery<UserProfile>({
    queryKey: ["/api/profile"],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return await apiRequest("POST", "/api/chat", { message: content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      setMessage("");
      scrollToBottom();
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось отправить сообщение",
        variant: "destructive",
      });
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedMessage = message.trim();
    
    if (!trimmedMessage) return;

    if (trimmedMessage.startsWith("/")) {
      handleCommand(trimmedMessage);
      return;
    }

    sendMessageMutation.mutate(trimmedMessage);
  };

  const handleCommand = (cmd: string) => {
    const lowerCmd = cmd.toLowerCase();
    
    if (lowerCmd.startsWith("/напоминание")) {
      if (lowerCmd.includes("список")) {
        setShowReminders(true);
      } else if (lowerCmd.includes("добавить")) {
        setShowReminders(true);
      } else {
        setShowCommands(true);
      }
      setMessage("");
    } else if (lowerCmd === "/команды" || lowerCmd === "/помощь") {
      setShowCommands(true);
      setMessage("");
    } else {
      toast({
        title: "Неизвестная команда",
        description: "Используйте /команды для просмотра доступных команд",
      });
      setMessage("");
    }
  };

  const formatTimestamp = (timestamp: Date | string) => {
    return new Date(timestamp).toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      <header className="border-b bg-card p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">МедАнализ-Ассистент</h1>
              <p className="text-sm text-muted-foreground">Ваш персональный медицинский помощник</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowCommands(true)}
              data-testid="button-commands"
            >
              <Command className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowReminders(true)}
              data-testid="button-reminders"
            >
              <Bell className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowProfile(true)}
              data-testid="button-profile"
            >
              <User className="w-5 h-5" />
            </Button>
            <Button
              variant="default"
              size="icon"
              onClick={() => setShowPdfUpload(true)}
              data-testid="button-upload-pdf"
            >
              <Upload className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-hidden flex flex-col max-w-4xl mx-auto w-full">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4 leading-relaxed">
            {messagesLoading ? (
              <div className="flex items-center justify-center p-8">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-12 text-center">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <FileText className="w-12 h-12 text-primary" />
                </div>
                <h2 className="text-xl font-semibold mb-2">Добро пожаловать!</h2>
                <p className="text-muted-foreground max-w-md leading-relaxed">
                  Я помогу вам разобраться с медицинскими анализами, симптомами и вопросами о здоровье. 
                  Загрузите PDF с результатами анализов или просто напишите ваш вопрос.
                </p>
                <div className="mt-6 flex gap-2">
                  <Button onClick={() => setShowPdfUpload(true)} data-testid="button-upload-start">
                    <Upload className="w-4 h-4 mr-2" />
                    Загрузить анализы
                  </Button>
                  <Button variant="outline" onClick={() => setShowCommands(true)} data-testid="button-help">
                    <Command className="w-4 h-4 mr-2" />
                    Команды
                  </Button>
                </div>
              </div>
            ) : (
              messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  data-testid={`message-${msg.role}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-4 ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-card border"
                    }`}
                  >
                    <div className="prose prose-sm max-w-none dark:prose-invert">
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>
                        {msg.content}
                      </ReactMarkdown>
                    </div>
                    <div className="mt-2 text-xs opacity-70">
                      {formatTimestamp(msg.timestamp)}
                    </div>
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        <MedicalDisclaimer />

        <div className="border-t bg-card p-4">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Введите ваш вопрос или /команды для помощи..."
              className="resize-none min-h-[60px] max-h-[120px] leading-relaxed"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage(e);
                }
              }}
              data-testid="input-message"
            />
            <Button
              type="submit"
              size="icon"
              className="min-h-[60px] w-[60px]"
              disabled={!message.trim() || sendMessageMutation.isPending}
              data-testid="button-send"
            >
              {sendMessageMutation.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </Button>
          </form>
        </div>
      </div>

      <PDFUpload open={showPdfUpload} onOpenChange={setShowPdfUpload} />
      <ReminderList open={showReminders} onOpenChange={setShowReminders} />
      <ProfileForm open={showProfile} onOpenChange={setShowProfile} profile={profile} />
      <CommandPalette open={showCommands} onOpenChange={setShowCommands} />
    </div>
  );
}
