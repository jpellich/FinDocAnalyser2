import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  Bell, 
  Trash2, 
  Plus, 
  Clock, 
  Calendar,
  Loader2,
  Pill
} from "lucide-react";
import type { MedicationReminder } from "@shared/schema";

interface ReminderListProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ReminderList({ open, onOpenChange }: ReminderListProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newReminder, setNewReminder] = useState({
    medication: "",
    dose: "",
    times: "",
    frequency: "daily",
    startDate: new Date().toISOString().split("T")[0],
    endDate: "",
    notes: "",
  });
  const { toast } = useToast();

  const { data: reminders = [], isLoading } = useQuery<MedicationReminder[]>({
    queryKey: ["/api/reminders"],
  });

  const addReminderMutation = useMutation({
    mutationFn: async (reminder: any) => {
      return await apiRequest("POST", "/api/reminders", {
        ...reminder,
        times: reminder.times.split(",").map((t: string) => t.trim()),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      toast({
        title: "Напоминание создано",
        description: "Новое напоминание успешно добавлено",
      });
      setShowAddForm(false);
      setNewReminder({
        medication: "",
        dose: "",
        times: "",
        frequency: "daily",
        startDate: new Date().toISOString().split("T")[0],
        endDate: "",
        notes: "",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать напоминание",
        variant: "destructive",
      });
    },
  });

  const deleteReminderMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/reminders/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      toast({
        title: "Напоминание удалено",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить напоминание",
        variant: "destructive",
      });
    },
  });

  const getFrequencyLabel = (frequency: string) => {
    const labels: Record<string, string> = {
      daily: "Ежедневно",
      weekly: "Еженедельно",
      every_2_days: "Каждые 2 дня",
      every_3_days: "Каждые 3 дня",
    };
    return labels[frequency] || frequency;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh]" data-testid="dialog-reminders">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl flex items-center gap-2">
              <Bell className="w-6 h-6 text-primary" />
              Напоминания о лекарствах
            </DialogTitle>
            <Button
              onClick={() => setShowAddForm(!showAddForm)}
              size="sm"
              data-testid="button-add-reminder"
            >
              <Plus className="w-4 h-4 mr-1" />
              Добавить
            </Button>
          </div>
        </DialogHeader>

        {showAddForm && (
          <Card className="p-4 space-y-4" data-testid="form-add-reminder">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="medication">Название лекарства *</Label>
                <Input
                  id="medication"
                  value={newReminder.medication}
                  onChange={(e) =>
                    setNewReminder({ ...newReminder, medication: e.target.value })
                  }
                  placeholder="Например: Аспирин"
                  data-testid="input-medication"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dose">Дозировка *</Label>
                <Input
                  id="dose"
                  value={newReminder.dose}
                  onChange={(e) =>
                    setNewReminder({ ...newReminder, dose: e.target.value })
                  }
                  placeholder="Например: 500мг"
                  data-testid="input-dose"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="times">Время приёма * (через запятую)</Label>
              <Input
                id="times"
                value={newReminder.times}
                onChange={(e) =>
                  setNewReminder({ ...newReminder, times: e.target.value })
                }
                placeholder="Например: 09:00, 21:00"
                data-testid="input-times"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="frequency">Частота</Label>
                <select
                  id="frequency"
                  value={newReminder.frequency}
                  onChange={(e) =>
                    setNewReminder({ ...newReminder, frequency: e.target.value })
                  }
                  className="w-full h-10 px-3 rounded-md border border-input bg-background"
                  data-testid="select-frequency"
                >
                  <option value="daily">Ежедневно</option>
                  <option value="weekly">Еженедельно</option>
                  <option value="every_2_days">Каждые 2 дня</option>
                  <option value="every_3_days">Каждые 3 дня</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="startDate">Дата начала</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={newReminder.startDate}
                  onChange={(e) =>
                    setNewReminder({ ...newReminder, startDate: e.target.value })
                  }
                  data-testid="input-start-date"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Заметки</Label>
              <Input
                id="notes"
                value={newReminder.notes}
                onChange={(e) =>
                  setNewReminder({ ...newReminder, notes: e.target.value })
                }
                placeholder="Дополнительные указания..."
                data-testid="input-notes"
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => addReminderMutation.mutate(newReminder)}
                disabled={
                  !newReminder.medication ||
                  !newReminder.dose ||
                  !newReminder.times ||
                  addReminderMutation.isPending
                }
                className="flex-1"
                data-testid="button-save-reminder"
              >
                {addReminderMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : null}
                Сохранить
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowAddForm(false)}
                data-testid="button-cancel-reminder"
              >
                Отмена
              </Button>
            </div>
          </Card>
        )}

        <ScrollArea className="max-h-[400px]">
          <div className="space-y-4 pr-4">
            {isLoading ? (
              <div className="flex items-center justify-center p-8">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : reminders.length === 0 ? (
              <div className="text-center p-8">
                <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
                  <Bell className="w-8 h-8 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground">
                  У вас пока нет напоминаний о лекарствах
                </p>
              </div>
            ) : (
              reminders.map((reminder) => (
                <Card key={reminder.id} className="p-4" data-testid={`reminder-card-${reminder.id}`}>
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Pill className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <h4 className="font-medium text-lg">{reminder.medication}</h4>
                          <p className="text-sm text-muted-foreground font-mono">
                            {reminder.dose}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteReminderMutation.mutate(reminder.id)}
                          data-testid={`button-delete-${reminder.id}`}
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="font-mono">{reminder.times.join(", ")}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">
                            {getFrequencyLabel(reminder.frequency)}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            с {new Date(reminder.startDate).toLocaleDateString("ru-RU")}
                          </span>
                        </div>
                        {reminder.notes && (
                          <p className="text-sm text-muted-foreground italic">
                            {reminder.notes}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
