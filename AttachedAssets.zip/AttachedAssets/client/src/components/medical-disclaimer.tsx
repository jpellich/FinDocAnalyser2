import { AlertTriangle } from "lucide-react";

export function MedicalDisclaimer() {
  return (
    <div className="border-t border-l-4 border-l-destructive bg-destructive/5 p-3" data-testid="medical-disclaimer">
      <div className="flex items-start gap-3 max-w-4xl mx-auto">
        <AlertTriangle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
        <div className="text-sm leading-relaxed">
          <p className="font-medium text-destructive">Медицинский дисклеймер</p>
          <p className="text-muted-foreground mt-1">
            Я не врач и не заменяю медицинскую помощь. При серьёзных или ухудшающихся симптомах 
            обязательно обратитесь к врачу. При угрожающих жизни симптомах немедленно вызовите скорую помощь.
          </p>
        </div>
      </div>
    </div>
  );
}
