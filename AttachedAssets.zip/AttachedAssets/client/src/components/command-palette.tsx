import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Command, Bell, ListPlus, Trash2, HelpCircle, Upload, User } from "lucide-react";

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const commands = [
  {
    command: "/напоминание добавить",
    icon: ListPlus,
    description: "Создать новое напоминание о приёме лекарства",
    example: "Откроет форму для добавления напоминания",
  },
  {
    command: "/напоминание список",
    icon: Bell,
    description: "Показать все активные напоминания",
    example: "Откроет список всех ваших напоминаний",
  },
  {
    command: "/напоминание удалить <id>",
    icon: Trash2,
    description: "Удалить напоминание по ID",
    example: "Удалит указанное напоминание",
  },
  {
    command: "/команды",
    icon: Command,
    description: "Показать список доступных команд",
    example: "Откроет это окно",
  },
  {
    command: "/помощь",
    icon: HelpCircle,
    description: "Получить помощь по использованию ассистента",
    example: "Откроет справочную информацию",
  },
];

export function CommandPalette({ open, onOpenChange }: CommandPaletteProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl" data-testid="dialog-commands">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <Command className="w-6 h-6 text-primary" />
            Доступные команды
          </DialogTitle>
          <DialogDescription className="leading-relaxed">
            Используйте команды для быстрого доступа к функциям ассистента
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {commands.map((cmd) => (
            <Card key={cmd.command} className="p-4 hover-elevate" data-testid={`command-${cmd.command}`}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <cmd.icon className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <code className="text-sm font-mono bg-muted px-2 py-1 rounded">
                      {cmd.command}
                    </code>
                  </div>
                  <p className="text-sm mb-1">{cmd.description}</p>
                  <p className="text-xs text-muted-foreground italic">
                    {cmd.example}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="mt-4 p-4 bg-muted/50 rounded-lg">
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <HelpCircle className="w-4 h-4" />
            Дополнительная информация
          </h4>
          <ul className="text-sm space-y-1 text-muted-foreground leading-relaxed">
            <li>• Команды можно вводить прямо в чате</li>
            <li>• Используйте кнопки в верхней панели для быстрого доступа</li>
            <li>• Загружайте PDF анализы через кнопку <Upload className="w-3 h-3 inline" /> в заголовке</li>
            <li>• Настройте профиль через кнопку <User className="w-3 h-3 inline" /> для персонализации</li>
          </ul>
        </div>
      </DialogContent>
    </Dialog>
  );
}
