import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2, User, Save } from "lucide-react";
import type { UserProfile } from "@shared/schema";

interface ProfileFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profile?: UserProfile;
}

export function ProfileForm({ open, onOpenChange, profile }: ProfileFormProps) {
  const [formData, setFormData] = useState({
    age: "",
    gender: "",
    chronicConditions: "",
    medications: "",
    allergies: "",
  });
  const { toast } = useToast();

  useEffect(() => {
    if (profile) {
      setFormData({
        age: profile.age || "",
        gender: profile.gender || "",
        chronicConditions: profile.chronicConditions?.join(", ") || "",
        medications: profile.medications?.join(", ") || "",
        allergies: profile.allergies?.join(", ") || "",
      });
    }
  }, [profile]);

  const saveProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/profile", {
        age: data.age,
        gender: data.gender,
        chronicConditions: data.chronicConditions
          .split(",")
          .map((c: string) => c.trim())
          .filter(Boolean),
        medications: data.medications
          .split(",")
          .map((m: string) => m.trim())
          .filter(Boolean),
        allergies: data.allergies
          .split(",")
          .map((a: string) => a.trim())
          .filter(Boolean),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      toast({
        title: "Профиль сохранён",
        description: "Ваши данные успешно обновлены",
      });
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось сохранить профиль",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveProfileMutation.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg" data-testid="dialog-profile">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <User className="w-6 h-6 text-primary" />
            Медицинский профиль
          </DialogTitle>
          <DialogDescription className="leading-relaxed">
            Эти данные помогут персонализировать рекомендации. Вся информация конфиденциальна.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="age">Возраст</Label>
              <Input
                id="age"
                value={formData.age}
                onChange={(e) =>
                  setFormData({ ...formData, age: e.target.value })
                }
                placeholder="Например: 35"
                data-testid="input-age"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gender">Пол</Label>
              <select
                id="gender"
                value={formData.gender}
                onChange={(e) =>
                  setFormData({ ...formData, gender: e.target.value })
                }
                className="w-full h-10 px-3 rounded-md border border-input bg-background"
                data-testid="select-gender"
              >
                <option value="">Не указан</option>
                <option value="male">Мужской</option>
                <option value="female">Женский</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="chronicConditions">
              Хронические заболевания (через запятую)
            </Label>
            <Input
              id="chronicConditions"
              value={formData.chronicConditions}
              onChange={(e) =>
                setFormData({ ...formData, chronicConditions: e.target.value })
              }
              placeholder="Например: диабет, гипертония"
              data-testid="input-chronic-conditions"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="medications">
              Принимаемые лекарства (через запятую)
            </Label>
            <Input
              id="medications"
              value={formData.medications}
              onChange={(e) =>
                setFormData({ ...formData, medications: e.target.value })
              }
              placeholder="Например: метформин, лизиноприл"
              data-testid="input-medications"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="allergies">Аллергии (через запятую)</Label>
            <Input
              id="allergies"
              value={formData.allergies}
              onChange={(e) =>
                setFormData({ ...formData, allergies: e.target.value })
              }
              placeholder="Например: пенициллин, орехи"
              data-testid="input-allergies"
            />
          </div>

          <div className="pt-4">
            <Button
              type="submit"
              className="w-full"
              disabled={saveProfileMutation.isPending}
              data-testid="button-save-profile"
            >
              {saveProfileMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Сохранение...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Сохранить профиль
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
