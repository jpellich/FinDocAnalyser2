# Design Guidelines: МедАнализ-Ассистент

## Design Approach

**System Selected:** Material Design 3 with healthcare-specific adaptations  
**Rationale:** Medical applications demand clarity, trust, and accessibility. Material Design's emphasis on hierarchy, readability, and structured information display aligns perfectly with medical data presentation needs.

**Core Principles:**
- Professional medical trustworthiness
- Information clarity over decoration
- Structured, scannable content blocks
- Obvious interaction affordances

---

## Typography System

**Font Family:** Inter (via Google Fonts CDN)
- Primary: Inter 400, 500, 600
- Monospace (for medical values): JetBrains Mono 400

**Hierarchy:**
- H1: text-4xl font-semibold (Page headers, "МедАнализ-Ассистент")
- H2: text-2xl font-semibold (Section headers: "Анализ крови")
- H3: text-xl font-medium (Subsections: "Гемоглобин")
- Body: text-base (Chat messages, descriptions)
- Small: text-sm (Timestamps, metadata)
- Caption: text-xs (Disclaimers, helper text)
- Medical Values: font-mono text-lg (Lab result numbers)

---

## Layout System

**Spacing Primitives:** Tailwind units 2, 4, 8, 12, 16
- Tight spacing: p-2, gap-2 (compact lists, inline elements)
- Standard spacing: p-4, gap-4 (cards, form fields)
- Section spacing: p-8, py-12 (major sections)
- Large breaks: py-16 (between major UI zones)

**Container Strategy:**
- Main chat area: max-w-4xl mx-auto (optimal reading width)
- Sidebar (reminders/commands): w-80 fixed
- Form inputs: max-w-md (comfortable form width)

**Grid Patterns:**
- Lab results: grid-cols-1 md:grid-cols-2 gap-4
- Command list: Single column with clear spacing
- Profile fields: grid-cols-1 gap-4

---

## Component Library

### Chat Interface
**Message Bubbles:**
- User messages: Right-aligned, rounded-2xl, p-4
- Assistant messages: Left-aligned, rounded-2xl, p-4, structured blocks
- Message spacing: gap-4 between messages
- Timestamp: text-xs, mt-2

**Structured Response Blocks:**
```
[Icon] Краткое резюме
────────────────────
Что означает
────────────────────
Причины (bulleted list)
────────────────────
Что делать
────────────────────
⚠️ Дисклеймер (highlighted)
```

### PDF Upload Zone
- Drag-and-drop area: min-h-48, border-2 border-dashed, rounded-xl, p-8
- Upload icon: 48x48px (Heroicons document-arrow-up)
- Status feedback: "PDF получен, извлекаю данные…" with spinner

### Medication Reminder Cards
- Card: rounded-xl, p-4, border
- Header: Medication name (text-lg font-medium)
- Details: Dose, times (font-mono), frequency
- Actions: Edit/Delete icons (Heroicons pencil/trash, 20x20px)
- List spacing: gap-4, vertical stack

### Command Palette
- Trigger: "/" in chat or button
- Overlay: Fixed bottom, rounded-t-2xl, p-4
- Command items: p-3, hover state, gap-2
- Icons: Heroicons (20x20px) - bell, list, trash, question-mark-circle

### Forms
**Input Fields:**
- Standard: h-12, px-4, rounded-lg, border
- Labels: text-sm font-medium, mb-2
- Helper text: text-xs, mt-1
- Field spacing: gap-4 vertical

**Buttons:**
- Primary CTA: h-12, px-6, rounded-lg, font-medium
- Secondary: h-10, px-4, rounded-lg
- Icon-only: w-10 h-10, rounded-lg
- Spacing in groups: gap-2

### Medical Disclaimer Banner
- Fixed positioning or pinned in view
- Rounded-xl, p-4, border-l-4
- Warning icon: Heroicons exclamation-triangle (24x24px)
- Text: text-sm font-medium
- Always visible with medical content

### Data Display
**Lab Results Table:**
- Row: p-4, border-b
- Columns: Test name | Value (font-mono) | Reference | Status
- Status indicators: Icons (Heroicons arrow-up/down, 16x16px)
- Responsive: Stack on mobile

---

## Icons

**Library:** Heroicons (via CDN)
**Usage:**
- Navigation: 24x24px
- Inline actions: 20x20px
- Status indicators: 16x16px
- Large feature icons: 48x48px

**Key Icons:**
- Chat: chat-bubble-left-right
- Upload: document-arrow-up
- Reminder: bell
- Commands: command-line
- Warning: exclamation-triangle
- Medical: beaker, clipboard-document-list
- Actions: pencil, trash, plus

---

## Special Considerations

### Russian Language Optimization
- Line-height: leading-relaxed (1.625) for Cyrillic readability
- Slightly increased letter-spacing for medical terms
- Generous paragraph spacing: space-y-4

### Medical Content Hierarchy
1. Critical warnings (disclaimers): Most prominent
2. Numerical values: Monospace, larger size
3. Explanations: Clear, readable body text
4. Metadata: Subdued, smaller

### Accessibility
- ARIA labels in Russian for screen readers
- Focus states: ring-2, ring-offset-2 on all interactive elements
- Minimum touch target: 44x44px
- High contrast text maintained throughout

---

## Images

**No hero images.** This is a medical utility application focused on functionality.

**Optional contextual imagery:**
- Empty states: Medical illustration (400x300px) for empty reminder list
- PDF processing: Document icon animation during extraction
- Profile section: Avatar placeholder (80x80px circle)

All images should be subtle, professional medical illustrations - never stock photos.